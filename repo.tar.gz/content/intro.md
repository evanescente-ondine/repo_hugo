---
title: Purpose of this website
---

![cover](/Images/heidelbergensis_kabwe.jpg)
{loading=eager}

This work describes a reversal of thinking
